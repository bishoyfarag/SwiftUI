//
//  BetterRestApp.swift
//  BetterRest
//
//  Created by csuftitan on 2/28/24.
//

import SwiftUI

@main
struct BetterRestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
